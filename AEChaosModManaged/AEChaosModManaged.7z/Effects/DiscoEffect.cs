﻿namespace AEChaosModManaged.Effects
{
    public class DiscoEffect : BaseEffect
    {
        public override string Name => "Disco";

        public override EffectType Type => EffectType.Disco;
    }
}
