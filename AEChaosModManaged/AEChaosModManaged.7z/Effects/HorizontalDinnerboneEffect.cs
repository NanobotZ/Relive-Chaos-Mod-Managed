﻿namespace AEChaosModManaged.Effects
{
    public class HorizontalDinnerboneEffect : BaseEffect
    {
        public override string Name => "Horizontal Dinnerbone";

        public override EffectType Type => EffectType.HorizontalDinnerbone;
    }
}
