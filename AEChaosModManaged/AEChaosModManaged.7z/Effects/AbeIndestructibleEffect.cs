﻿namespace AEChaosModManaged.Effects
{
    public class AbeIndestructibleEffect : BaseEffect
    {
        public override string Name => "Indestructible Abe";

        public override EffectType Type => EffectType.IndestructibleAbe;
    }
}
