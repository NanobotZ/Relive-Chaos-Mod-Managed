﻿namespace AEChaosModManaged.Effects
{
    public class SuperhotEffect : BaseEffect
    {
        public override string Name => "SUPERHOT";

        public override EffectType Type => EffectType.Superhot;
    }
}
