﻿namespace AEChaosModManaged.Effects
{
    public class ShrykullGrenadesEffect : BaseEffect
    {
        public override string Name => "Shrykull Grenades";

        public override EffectType Type => EffectType.ShrykullGrenades;
    }
}
