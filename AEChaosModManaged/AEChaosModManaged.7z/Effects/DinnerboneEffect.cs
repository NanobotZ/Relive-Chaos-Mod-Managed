﻿namespace AEChaosModManaged.Effects
{
    public class DinnerboneEffect : BaseEffect
    {
        public override string Name => "Dinnerbone";

        public override EffectType Type => EffectType.Dinnerbone;
    }
}
