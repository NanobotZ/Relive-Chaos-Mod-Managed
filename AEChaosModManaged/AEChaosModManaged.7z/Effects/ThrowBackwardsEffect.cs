﻿namespace AEChaosModManaged.Effects
{
    public class ThrowBackwardsEffect : BaseEffect
    {
        public override string Name => "Throw Backwards";

        public override EffectType Type => EffectType.ThrowBackwards;
    }
}
