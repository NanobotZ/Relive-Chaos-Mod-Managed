﻿namespace AEChaosModManaged.Effects
{
    public class FatAbeEffect : BaseEffect
    {
        public override string Name => "Fat Abe";

        public override EffectType Type => EffectType.FatAbe;
    }
}
